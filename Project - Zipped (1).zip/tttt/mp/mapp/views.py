from django.shortcuts import render

# Create your views here.

def fun(request):
    return render(request,'home.html')

def login(request):
    return render(request,'login.html')
def logout(request):
    return render(request,'logout.html')
def menu(request):
    return render(request,'menu.html')
def about(request):
    return render(request,'about.html')
def project(request):
    return render(request,'project.html')
