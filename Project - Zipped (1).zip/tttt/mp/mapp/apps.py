from django.apps import AppConfig


class MappConfig(AppConfig):
    name = 'mapp'
